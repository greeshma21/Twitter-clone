import whoJson from './data/who.json';

const who = (state = whoJson) => {
    return(state);
};

export default who;
